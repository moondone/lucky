
const messages = [
  "사랑합니다",
  "감사합니다",
  "고맙습니다",
  "행운이 올 거예요",
  "도네 최공",
  "오늘도 멋져요",
  "믿고 있어요",
  "마음이 따뜻해지는 하루",
  "작은 기적이 일어날 거예요",
  "당신은 소중한 사람이에요"
];

const drawButton = document.getElementById("draw-button");
const messageSection = document.getElementById("message-section");
const messageDiv = document.getElementById("message");
const copyButton = document.getElementById("copy-button");
const shareButton = document.getElementById("share-button");
const retryButton = document.getElementById("retry-button");

drawButton.addEventListener("click", () => {
  const randomMessage = messages[Math.floor(Math.random() * messages.length)];
  messageDiv.textContent = randomMessage;
  messageSection.classList.remove("hidden");
  drawButton.style.display = "none";
});

copyButton.addEventListener("click", () => {
  navigator.clipboard.writeText(messageDiv.textContent)
    .then(() => alert("복사되었어요!"));
});

shareButton.addEventListener("click", () => {
  const text = encodeURIComponent(messageDiv.textContent);
  const url = `https://share.kakao.com/?text=${text}`;
  window.open(url, "_blank");
});

retryButton.addEventListener("click", () => {
  const randomMessage = messages[Math.floor(Math.random() * messages.length)];
  messageDiv.textContent = randomMessage;
});
